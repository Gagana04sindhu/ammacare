package com.example.ammacareversion0;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// Enum to represent trimesters for better type safety
enum Trimester {
    FIRST, SECOND, THIRD
}

public class WorkoutActivity extends AppCompatActivity {

    private List<WorkoutVideo> allVideos;
    private WorkoutAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        Button homeButton = findViewById(R.id.homeButton);
        RecyclerView workoutRecyclerView = findViewById(R.id.workoutRecyclerView);
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        homeButton.setOnClickListener(v -> finish());

        // Initialize the master list of all videos
        allVideos = getWorkoutVideos();

        // Setup RecyclerView with an adapter
        workoutRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WorkoutAdapter(new ArrayList<>()); // Start with an empty list
        workoutRecyclerView.setAdapter(adapter);

        // Listener for tab selections
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Filter the list based on the selected tab
                filterVideosByTrimester(Trimester.values()[tab.getPosition()]);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Initially display videos for the first trimester
        filterVideosByTrimester(Trimester.FIRST);
    }

    /**
     * Filters the master video list and updates the RecyclerView adapter.
     * @param trimester The trimester to display videos for.
     */
    private void filterVideosByTrimester(Trimester trimester) {
        // Use Java 8 streams to filter the list.
        List<WorkoutVideo> filteredList = allVideos.stream()
                .filter(video -> video.trimester == trimester)
                .collect(Collectors.toList());
        adapter.updateData(filteredList);
    }

    /**
     * Creates the master list of all workout videos with their associated trimester.
     * @return A list of WorkoutVideo objects.
     */
    private List<WorkoutVideo> getWorkoutVideos() {
        List<WorkoutVideo> videos = new ArrayList<>();

        // First Trimester Videos
        videos.add(new WorkoutVideo("Walking", "Gentle cardio to maintain fitness and boost mood.", "d_wE_y-w-cQ", Trimester.FIRST));
        videos.add(new WorkoutVideo("Pelvic Floor Exercises (Kegels)", "Strengthens muscles supporting the uterus and bladder.", "Z-4q0c_O4_M", Trimester.FIRST));

        // Second Trimester Videos
        videos.add(new WorkoutVideo("Prenatal Yoga for Beginners", "Improves flexibility, balance, and reduces stress.", "1bgZ_Ac48aI", Trimester.SECOND));
        videos.add(new WorkoutVideo("Stationary Cycling", "Low-impact cardio that's easy on the joints.", "SgQ_J_mdj4Y", Trimester.SECOND));

        // Third Trimester Videos
        videos.add(new WorkoutVideo("Pelvic Tilts (Cat-Cow)", "Helps relieve back pain common in the third trimester.", "B5Xv-K_V-iM", Trimester.THIRD));
        videos.add(new WorkoutVideo("Wall Sits", "Builds leg and core strength in preparation for labor.", "y-wV4j5-o_c", Trimester.THIRD));

        return videos;
    }
}

/**
 * Data class for a Workout Video, now with a trimester property.
 */
class WorkoutVideo {
    String title;
    String description;
    String youtubeVideoId;
    Trimester trimester;

    WorkoutVideo(String title, String description, String youtubeVideoId, Trimester trimester) {
        this.title = title;
        this.description = description;
        this.youtubeVideoId = youtubeVideoId;
        this.trimester = trimester;
    }
}

/**
 * Adapter for the RecyclerView. Now includes a method to update its data.
 */
class WorkoutAdapter extends RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder> {

    private List<WorkoutVideo> videoList;

    public WorkoutAdapter(List<WorkoutVideo> videoList) {
        this.videoList = videoList;
    }

    // New method to update the list and refresh the RecyclerView
    public void updateData(List<WorkoutVideo> newVideoList) {
        this.videoList.clear();
        this.videoList.addAll(newVideoList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public WorkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_workout_video, parent, false);
        return new WorkoutViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkoutViewHolder holder, int position) {
        WorkoutVideo video = videoList.get(position);
        holder.title.setText(video.title);
        holder.description.setText(video.description);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + video.youtubeVideoId));
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=" + video.youtubeVideoId));
            try {
                v.getContext().startActivity(intent);
            } catch (ActivityNotFoundException e) {
                v.getContext().startActivity(webIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }

    static class WorkoutViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView description;

        public WorkoutViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.videoTitleTextView);
            description = itemView.findViewById(R.id.videoDescTextView);
        }
    }
}