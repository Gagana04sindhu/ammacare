package com.example.ammacareversion0;

// All necessary imports
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class VaccinationTrackerActivity extends AppCompatActivity {

    // Class-level variables for the list and adapter
    private List<Vaccine> vaccineList;
    private VaccineAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vaccination_tracker);

        Button homeButton = findViewById(R.id.homeButton);
        RecyclerView vaccineRecyclerView = findViewById(R.id.vaccineRecyclerView);
        // Find the new FloatingActionButton
        FloatingActionButton fab = findViewById(R.id.fab_add_vaccine);

        // Home button navigation
        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(VaccinationTrackerActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        // Initialize list and adapter
        vaccineList = getVaccineData();
        adapter = new VaccineAdapter(vaccineList);
        vaccineRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        vaccineRecyclerView.setAdapter(adapter);

        // Set click listener for the FAB to show the dialog
        fab.setOnClickListener(view -> showAddVaccineDialog());
    }

    /**
     * Creates and displays an AlertDialog for adding a custom vaccine appointment.
     */
    private void showAddVaccineDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_vaccine, null);
        builder.setView(dialogView);

        final EditText vaccineNameEditText = dialogView.findViewById(R.id.edit_text_vaccine_name);
        final Button pickDateButton = dialogView.findViewById(R.id.button_pick_date);
        final Calendar calendar = Calendar.getInstance();

        // Show DatePickerDialog when the "Pick Date" button is clicked
        pickDateButton.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                calendar.set(year, month, dayOfMonth);
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                pickDateButton.setText(sdf.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        // Set up the "Save" and "Cancel" buttons
        builder.setPositiveButton("Save", (dialog, which) -> {
            String vaccineName = vaccineNameEditText.getText().toString();
            String vaccineDate = pickDateButton.getText().toString();

            // Add the new vaccine to the list and notify the adapter
            if (!vaccineName.isEmpty() && !vaccineDate.equals("Pick Appointment Date")) {
                vaccineList.add(new Vaccine(vaccineName, vaccineDate, false));
                adapter.notifyItemInserted(vaccineList.size() - 1);
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /**
     * Provides the initial list of standard vaccines.
     * @return A list of Vaccine objects.
     */
    private List<Vaccine> getVaccineData() {
        List<Vaccine> vaccines = new ArrayList<>();
        // Mother's Vaccines
        vaccines.add(new Vaccine("Td-1", "During early pregnancy", false));
        vaccines.add(new Vaccine("Td-2", "4 weeks after Td-1", false));
        vaccines.add(new Vaccine("Td Booster", "If received 2 doses in a pregnancy within the last 3 years", false));
        // Baby's Vaccines
        vaccines.add(new Vaccine("BCG, OPV 0, Hep-B 1", "At Birth", false));
        vaccines.add(new Vaccine("DTwP 1, IPV 1, Hib 1, Rotavirus 1, PCV 1", "At 6 weeks", false));
        vaccines.add(new Vaccine("DTwP 2, IPV 2, Hib 2, Rotavirus 2, PCV 2", "At 10 weeks", false));
        vaccines.add(new Vaccine("DTwP 3, IPV 3, Hib 3, Rotavirus 3, PCV 3", "At 14 weeks", false));
        vaccines.add(new Vaccine("MMR-1", "At 9 months", false));
        return vaccines;
    }
}

/**
 * Data class to hold information about a single vaccine.
 */
class Vaccine {
    String name;
    String dueDate;
    boolean isCompleted;

    Vaccine(String name, String dueDate, boolean isCompleted) {
        this.name = name;
        this.dueDate = dueDate;
        this.isCompleted = isCompleted;
    }
}

/**
 * Adapter for the RecyclerView that displays the list of vaccines.
 */
class VaccineAdapter extends RecyclerView.Adapter<VaccineAdapter.VaccineViewHolder> {

    private List<Vaccine> vaccineList;

    public VaccineAdapter(List<Vaccine> vaccineList) {
        this.vaccineList = vaccineList;
    }

    @NonNull
    @Override
    public VaccineViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_vaccine, parent, false);
        return new VaccineViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VaccineViewHolder holder, int position) {
        Vaccine vaccine = vaccineList.get(position);
        holder.vaccineName.setText(vaccine.name);
        holder.vaccineDueDate.setText("Due: " + vaccine.dueDate);
        holder.vaccineStatus.setChecked(vaccine.isCompleted);

        holder.vaccineStatus.setOnCheckedChangeListener((buttonView, isChecked) -> {
            vaccine.isCompleted = isChecked;
            // Here you would later add code to save this status to a database
        });
    }

    @Override
    public int getItemCount() {
        return vaccineList.size();
    }

    static class VaccineViewHolder extends RecyclerView.ViewHolder {
        TextView vaccineName;
        TextView vaccineDueDate;
        CheckBox vaccineStatus;

        public VaccineViewHolder(@NonNull View itemView) {
            super(itemView);
            vaccineName = itemView.findViewById(R.id.vaccineNameTextView);
            vaccineDueDate = itemView.findViewById(R.id.vaccineDueDateTextView);
            vaccineStatus = itemView.findViewById(R.id.vaccineStatusCheckBox);
        }
    }
}