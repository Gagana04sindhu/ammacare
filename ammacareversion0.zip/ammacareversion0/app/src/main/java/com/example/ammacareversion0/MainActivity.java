package com.example.ammacareversion0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button periodTrackerButton = findViewById(R.id.buttonPeriodTracker);
        Button healthRemindersButton = findViewById(R.id.buttonHealthReminders);
        Button vaccinationTrackerButton = findViewById(R.id.buttonVaccinationTracker);
        Button workoutButton = findViewById(R.id.buttonWorkout);



        // Click listener for the Period & Mood Tracker button
        periodTrackerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LogPeriodActivity.class);
                startActivity(intent);
            }
        });

        // Click listener for the Daily Health Reminders button
        healthRemindersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SetReminderActivity.class);
                startActivity(intent);
            }
        });



        // The Vaccination Tracker button does not have a destination yet.
        // This functionality will be implemented later.
        vaccinationTrackerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, VaccinationTrackerActivity.class);
                startActivity(intent);
            }
        });


        workoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This Intent starts the WorkoutActivity
                Intent intent = new Intent(MainActivity.this, WorkoutActivity.class);
                startActivity(intent);
            }
        });

    }
}
