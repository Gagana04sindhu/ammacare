package com.example.ammacareversion0;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LogSymptomsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_symptoms);


        String selectedDate = getIntent().getStringExtra("SELECTED_DATE");


        TextView dateDisplay = findViewById(R.id.selected_date_display);
        if (selectedDate != null) {
            dateDisplay.setText(selectedDate);
        } else {
            dateDisplay.setText("No date received");
        }

        Button saveButton = findViewById(R.id.save_symptoms_button);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LogSymptomsActivity.this, "Symptoms Logged Successfully!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}