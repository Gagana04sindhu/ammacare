package com.example.ammacareversion0;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

//import com.example.ammacarefullpy.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView recyclerChatMessages;
    private EditText etMessageInput;
    private ImageButton btnSend, btnCameraPhoto, btnCameraVideo, btnVoice;
    private ChatAdapter chatAdapter;
    private List<String> chatMessages;

    private static final int PERMISSION_REQUEST_CODE = 100;

    // Media
    private ActivityResultLauncher<Intent> cameraPhotoLauncher;
    private ActivityResultLauncher<Intent> cameraVideoLauncher;

    // Audio Recording
    private MediaRecorder mediaRecorder;
    private boolean isRecording = false;
    private String audioFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Initialize Views
        recyclerChatMessages = findViewById(R.id.recyclerChatMessages);
        etMessageInput = findViewById(R.id.etMessageInput);
        btnSend = findViewById(R.id.btnSend);
        btnCameraPhoto = findViewById(R.id.btnCamera); // Camera button = photo
        btnCameraVideo = findViewById(R.id.btnVideo);  // You need to add a Video button in XML
        btnVoice = findViewById(R.id.btnVoice);

        // Setup RecyclerView
        chatMessages = new ArrayList<>();
        chatAdapter = new ChatAdapter(chatMessages);
        recyclerChatMessages.setLayoutManager(new LinearLayoutManager(this));
        recyclerChatMessages.setAdapter(chatAdapter);

        // ==================
        // Camera (Photo)
        // ==================
        cameraPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle extras = result.getData().getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        addMessage("📷 Photo captured!");
                    }
                });

        // ==================
        // Camera (Video)
        // ==================
        cameraVideoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri videoUri = result.getData().getData();
                        addMessage("🎥 Video recorded: " + videoUri.toString());
                    }
                });

        // ==================
        // Buttons
        // ==================
        btnSend.setOnClickListener(v -> {
            String message = etMessageInput.getText().toString().trim();
            if (!message.isEmpty()) {
                addMessage("You: " + message);
                etMessageInput.setText("");
            }
        });

        btnCameraPhoto.setOnClickListener(v -> openCameraPhoto());
        btnCameraVideo.setOnClickListener(v -> openCameraVideo());

        btnVoice.setOnClickListener(v -> toggleAudioRecording());

        // Ask permissions
        checkPermissions();
    }

    // ==================
    // Messages
    // ==================
    private void addMessage(String message) {
        chatMessages.add(message);
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        recyclerChatMessages.scrollToPosition(chatMessages.size() - 1);
    }

    // ==================
    // Camera Photo
    // ==================
    private void openCameraPhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraPhotoLauncher.launch(takePictureIntent);
        } else {
            Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show();
            checkPermissions();
        }
    }

    // ==================
    // Camera Video
    // ==================
    private void openCameraVideo() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            cameraVideoLauncher.launch(takeVideoIntent);
        } else {
            Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show();
            checkPermissions();
        }
    }

    // ==================
    // Audio Recording
    // ==================
    private void toggleAudioRecording() {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    }

    private void startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            checkPermissions();
            return;
        }

        File outputDir = getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (outputDir != null) {
            audioFilePath = outputDir.getAbsolutePath() + "/recording_" + System.currentTimeMillis() + ".3gp";
        }

        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setOutputFile(audioFilePath);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
            isRecording = true;
            addMessage("🎤 Recording started...");
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Recording failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopRecording() {
        if (isRecording && mediaRecorder != null) {
            try {
                mediaRecorder.stop();
                mediaRecorder.release();
                mediaRecorder = null;
                isRecording = false;
                addMessage("🎤 Audio saved: " + audioFilePath);
            } catch (RuntimeException e) {
                e.printStackTrace();
                Toast.makeText(this, "Error stopping recording", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ==================
    // Permissions
    // ==================
    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permissions denied. Some features may not work.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ==================
    // RecyclerView Adapter
    // ==================
    static class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {
        private List<String> chatMessages;

        ChatAdapter(List<String> chatMessages) {
            this.chatMessages = chatMessages;
        }

        @NonNull
        @Override
        public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.activity_chat_item, parent, false);
            return new ChatViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
            holder.textMessage.setText(chatMessages.get(position));
        }

        @Override
        public int getItemCount() {
            return chatMessages.size();
        }

        static class ChatViewHolder extends RecyclerView.ViewHolder {
            TextView textMessage;

            ChatViewHolder(@NonNull View itemView) {
                super(itemView);
                textMessage = itemView.findViewById(R.id.textMessage);
            }
        }
 }
}