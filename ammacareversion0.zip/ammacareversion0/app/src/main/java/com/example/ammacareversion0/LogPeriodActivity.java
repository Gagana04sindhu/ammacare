package com.example.ammacareversion0;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class LogPeriodActivity extends AppCompatActivity {

    private String selectedDate;
    private TextView noPeriodTextView;

    // --- IMPORTANT: This is a simulated last period start date and cycle length ---
    // For a real app, you would save and retrieve this data from a database.
    private static final String LAST_PERIOD_START_DATE_STRING = "01/09/2025";
    private static final int CYCLE_LENGTH_DAYS = 28;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_period);

        CalendarView calendarView = findViewById(R.id.calendarView);
        Button logButton = findViewById(R.id.logButton);
        Button homeButton = findViewById(R.id.homeButton);
        noPeriodTextView = findViewById(R.id.NoPeriod);

        // Set up the initial date and update the period status
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        selectedDate = sdf.format(new Date(calendarView.getDate()));
        updatePeriodStatus(selectedDate);

        // Listen for a date change on the calendar
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, dayOfMonth);
                selectedDate = sdf.format(calendar.getTime());

                // Update the period status whenever the date is changed
                updatePeriodStatus(selectedDate);
            }
        });

        // Set up the button click listener
        logButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedDate != null) {
                    Intent intent = new Intent(LogPeriodActivity.this, LogSymptomsActivity.class);
                    // Pass the selected date as an extra to the next activity
                    intent.putExtra("SELECTED_DATE", selectedDate);
                    startActivity(intent);
                } else {
                    Toast.makeText(LogPeriodActivity.this, "Please select a date.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to navigate back to the MainActivity (the home page)
                Intent intent = new Intent(LogPeriodActivity.this, MainActivity.class);
                // Clear the back stack to prevent the user from returning to this activity with the back button
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }

    /**
     * This method calculates and updates the period status TextView.
     * Note: This is a simplified, hardcoded example for demonstration.
     */
    private void updatePeriodStatus(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {
            Date lastPeriodStartDate = sdf.parse(LAST_PERIOD_START_DATE_STRING);
            Date selectedDate = sdf.parse(dateString);

            long diffMillis = selectedDate.getTime() - lastPeriodStartDate.getTime();
            long diffDays = diffMillis / (1000 * 60 * 60 * 24);

            // Calculate the day of the current cycle
            long dayOfCycle = (diffDays % CYCLE_LENGTH_DAYS) + 1;

            // Assuming a period length of 5 days
            if (dayOfCycle >= 1 && dayOfCycle <= 5) {
                noPeriodTextView.setText("Day " + dayOfCycle + " of period");
            } else {
                long daysToNextPeriod = CYCLE_LENGTH_DAYS - dayOfCycle + 1;
                noPeriodTextView.setText("Period in " + daysToNextPeriod + " days");
            }
        } catch (Exception e) {
            e.printStackTrace();
            noPeriodTextView.setText("Error calculating period.");
        }
    }
}

