package com.example.ammacareversion0;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SetReminderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_reminder);

        // Find the UI elements
        EditText editTextReminderMessage = findViewById(R.id.editTextReminderMessage);
        TimePicker timePicker = findViewById(R.id.timePicker);
        Button buttonSetReminder = findViewById(R.id.buttonSetReminder);
        Button homeButton = findViewById(R.id.homeButton);

        // Find the CheckBoxes for the days of the week
        CheckBox checkboxSunday = findViewById(R.id.checkboxSunday);
        CheckBox checkboxMonday = findViewById(R.id.checkboxMonday);
        CheckBox checkboxTuesday = findViewById(R.id.checkboxTuesday);
        CheckBox checkboxWednesday = findViewById(R.id.checkboxWednesday);
        CheckBox checkboxThursday = findViewById(R.id.checkboxThursday);
        CheckBox checkboxFriday = findViewById(R.id.checkboxFriday);
        CheckBox checkboxSaturday = findViewById(R.id.checkboxSaturday);

        buttonSetReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String reminderMessage = editTextReminderMessage.getText().toString();

                if (reminderMessage.isEmpty()) {
                    Toast.makeText(SetReminderActivity.this, "Please enter a reminder message.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Get the selected time from the TimePicker
                int hour = timePicker.getCurrentHour();
                int minute = timePicker.getCurrentMinute();

                // Get the list of selected days
                List<Integer> selectedDays = new ArrayList<>();
                if (checkboxSunday.isChecked()) selectedDays.add(Calendar.SUNDAY);
                if (checkboxMonday.isChecked()) selectedDays.add(Calendar.MONDAY);
                if (checkboxTuesday.isChecked()) selectedDays.add(Calendar.TUESDAY);
                if (checkboxWednesday.isChecked()) selectedDays.add(Calendar.WEDNESDAY);
                if (checkboxThursday.isChecked()) selectedDays.add(Calendar.THURSDAY);
                if (checkboxFriday.isChecked()) selectedDays.add(Calendar.FRIDAY);
                if (checkboxSaturday.isChecked()) selectedDays.add(Calendar.SATURDAY);

                if (selectedDays.isEmpty()) {
                    Toast.makeText(SetReminderActivity.this, "Please select at least one day.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Schedule a separate alarm for each selected day
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                long intervalDay = AlarmManager.INTERVAL_DAY * 7; // Weekly repeating alarm

                for (int dayOfWeek : selectedDays) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(Calendar.HOUR_OF_DAY, hour);
                    calendar.set(Calendar.MINUTE, minute);
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.DAY_OF_WEEK, dayOfWeek);

                    // If the alarm time has already passed this week, schedule it for the next week
                    if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
                        calendar.add(Calendar.DAY_OF_WEEK, 7);
                    }

                    // Use a unique request code for each pending intent to avoid conflicts
                    int requestCode = (int) System.currentTimeMillis() + dayOfWeek;

                    Intent intent = new Intent(SetReminderActivity.this, ReminderBroadcastReceiver.class);
                    intent.putExtra("REMINDER_MESSAGE", reminderMessage);

                    PendingIntent pendingIntent = PendingIntent.getBroadcast(SetReminderActivity.this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                    alarmManager.setRepeating(
                            AlarmManager.RTC_WAKEUP,
                            calendar.getTimeInMillis(),
                            intervalDay,
                            pendingIntent
                    );
                }

                Toast.makeText(SetReminderActivity.this, "Reminders set successfully! ", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        // Click listener for the Home button to go back to the main activity
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SetReminderActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}
